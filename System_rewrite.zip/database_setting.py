import json
import uuid
import tkinter.messagebox as tm

import pandas as pd
import ttkbootstrap as ttks
from ttkbootstrap.constants import *
from tkinter import *
from tkinter import filedialog


class Database(Toplevel):
    def __init__(self, windows=None):
        super().__init__(windows)
        self.if_save = False
        self.style = ttks.Style(theme='litera')
        self.title('数据库')
        self.resizable(width=False, height=False)
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        ww = 1080
        wh = 900
        x = (sw - ww) / 2
        y = (sh - wh) / 2
        self.geometry("%dx%d+%d+%d" % (ww, wh, x, y))
        self.table = ttks.Treeview(self)
        self.times = {"Ordercode": 0, "Ordercode": 0, "SMT1": 0, "SMT2": 0, "SMT3": 0, "SMT4": 0, "stdT": 0}
        self.table['columns'] = ('Ordercode', 'Ordertype', 'SMT1', 'SMT2', 'SMT3', 'SMT4', 'stdT')
        self.table.column("#0", width=0)
        self.table.column("Ordercode", width=150, anchor='center')
        self.table.column("Ordertype", width=350)
        self.table.column("SMT1", width=75, anchor='center')
        self.table.column("SMT2", width=75, anchor='center')
        self.table.column("SMT3", width=75, anchor='center')
        self.table.column("SMT4", width=75, anchor='center')
        self.table.column("stdT", width=75, anchor='center')

        self.table.heading("Ordercode", text="订单编号", command=lambda: self.sort_treeview("Ordercode"))
        self.table.heading("Ordertype", text="线路板类型")
        self.table.heading("SMT1", text="SMT1", command=lambda: self.sort_treeview("SMT1"))
        self.table.heading("SMT2", text="SMT2", command=lambda: self.sort_treeview("SMT2"))
        self.table.heading("SMT3", text="SMT3", command=lambda: self.sort_treeview("SMT3"))
        self.table.heading("SMT4", text="SMT4", command=lambda: self.sort_treeview("SMT4"))
        self.table.heading("stdT", text="标准工时", command=lambda: self.sort_treeview("stdT"))
        self.table.place(x=0, y=100, width=1060, height=790)
        self.scroll1 = Scrollbar(self, command=self.table.yview)
        self.table.configure(yscrollcommand=self.scroll1.set)
        self.scroll1.place(x=1060, y=100, height=790, width=20)

        with open("./database/data.json", "r") as f:
            self.parsed_data = json.load(f)
        excel = []
        for code, i in self.parsed_data.items():
            for a, b in i.items():
                l1 = []
                l1.append(str(code))
                l1.append(a)
                l1 = l1 + b
                excel.append(l1)
        for i, item in enumerate(excel):
            new_iid = str(uuid.uuid4())
            self.table.insert(parent="", index=i, iid=new_iid, values=item, tags=("editable"))

        self.b1 = ttks.Button(self, text="新   建", command=self.create, bootstyle=SUCCESS)
        self.b1.place(x=10, y=10, width=180, height=30)
        self.b6 = ttks.Button(self, text="批量导入", command=self.batch_create, bootstyle=SUCCESS)
        self.b6.place(x=200, y=10, width=180, height=30)
        self.b2 = ttks.Button(self, text="编   辑", command=self.edit_row, bootstyle=SUCCESS)
        self.b2.place(x=390, y=10, width=180, height=30)
        self.b3 = ttks.Button(self, text="删   除", command=self.backspace, bootstyle=SUCCESS)
        self.b3.place(x=580, y=10, width=180, height=30)
        self.b4 = ttks.Button(self, text="保   存", command=self.save, bootstyle=SUCCESS)
        self.b4.place(x=770, y=10, width=180, height=30)
        self.b5 = ttks.Button(self, text="退   出", command=self.if_quit, bootstyle=(PRIMARY, "outline-toolbutton"))
        self.b5.place(x=960, y=10, width=110, height=30)
        # 创建一个label，显示当前TreeView的总行数
        self.label = Label(self, text="物料总数：")
        self.label.place(x=10, y=60, width=100, height=30)
        self.label1 = Label(self, text="0")
        self.label1.place(x=110, y=60, width=100, height=30)
        self.get_row()

        self.table.tag_bind("editable", "<Double-1>", self.edit_row)

    def create(self):
        names = ["订单编号", "线路板类型", "SMT1", "SMT2", "SMT3", "SMT4", "标准工时"]
        edit_window = Toplevel(self)
        edit_window.title("新建")
        edit_window.geometry("300x300")
        ks = []
        for i, item in enumerate(names):
            Label(edit_window, text=names[i] + ":", anchor=CENTER).place(x=10, y=30 + i * 30, width=100, height=20)
            name_entry = Entry(edit_window)
            name_entry.insert(0, '')
            name_entry.place(x=110, y=30 + i * 30, width=170, height=20)
            ks.append(name_entry)

        def save_edits():
            new_iid = str(uuid.uuid4())
            new_values = tuple(i.get() for i in ks)
            self.table.insert("", END, iid=new_iid, values=new_values, tags=("editable"))
            edit_window.destroy()

        save_button = ttks.Button(edit_window, text="保存", command=save_edits, bootstyle=SUCCESS)
        save_button.place(x=10, y=250, height=30, width=100)
        quit_button = ttks.Button(edit_window, text="取消", command=edit_window.destroy,
                                  bootstyle=(PRIMARY, "outline-toolbutton"))
        quit_button.place(x=190, y=250, height=30, width=100)
        self.get_row()

    def backspace(self):
        selected_row = self.table.selection()
        for row in selected_row:
            self.table.delete(row)
        self.get_row()

    def save(self):
        self.if_save = True
        # 将self.table中的数据保存到json文件中
        all_data = []
        new_data = {}
        for child in self.table.get_children():
            dicts = {}
            values = self.table.item(child)['values']
            dicts[values[1]] = values[2:]
            if values[0] in new_data:
                new_data[values[0]].update(dicts)
            else:
                new_data[values[0]] = dicts
        with open("./database/data.json", "w") as f:
            json.dump(new_data, f, indent=4)
        # 在当前toplevel弹出保存成功的提示框，弹出时self保持在最前
        self.bell()
        self.focus_force()
        tm.showinfo("保存成功", "保存成功", parent=self)

    def if_quit(self):
        # 弹窗询问是否保存，若是则保存并退出，否则直接退出
        if self.if_save:
            self.destroy()
        else:
            if tm.askyesno("退出", "是否保存并退出？", parent=self):
                self.save()
                self.destroy()
            else:
                self.destroy()

    def edit_row(self, event=None):
        if event is None:
            row = self.table.selection()[0]
        else:
            row = self.table.identify_row(event.y)
        values = self.table.item(row)["values"]
        names = ["订单编号", "线路板类型", "SMT1", "SMT2", "SMT3", "SMT4", "标准工时"]
        edit_window = Toplevel(self)
        edit_window.title("编辑")
        edit_window.geometry("300x300")
        ks = []
        for i, item in enumerate(values):
            Label(edit_window, text=names[i] + ":", anchor=CENTER).place(x=10, y=30 + i * 30, width=100, height=20)
            name_entry = Entry(edit_window)
            name_entry.insert(0, item)
            name_entry.place(x=110, y=30 + i * 30, width=170, height=20)
            ks.append(name_entry)

        def save_edits():
            new_values = tuple(i.get() for i in ks)
            self.table.item(row, values=new_values)
            edit_window.destroy()

        save_button = ttks.Button(edit_window, text="保存", command=save_edits, bootstyle=SUCCESS)
        save_button.place(x=10, y=250, height=30, width=100)
        quit_button = ttks.Button(edit_window, text="取消", command=edit_window.destroy,
                                  bootstyle=(PRIMARY, "outline-toolbutton"))
        quit_button.place(x=190, y=250, height=30, width=100)
        self.get_row()

    def sort_treeview(self, column):
        self.times[column] += 1
        items = self.table.get_children()
        items = sorted(items, key=lambda x: float(self.table.set(x, column)),
                       reverse=True if self.times[column] % 2 == 0 else False)
        for index, item in enumerate(items):
            self.table.move(item, "", index)
        self.times[column] %= 2

    def get_row(self):
        last_item_id = self.table.get_children()[-1]
        self.total_rows = int(self.table.index(last_item_id)) + 1
        self.label1.config(text=self.total_rows)
        self.if_save = False

    def batch_create(self):
        # 提示选取要导入的文件，类型有excel的xlsx，xls，和记事本的txt
        file_path = ''
        file_path = filedialog.askopenfilename(parent=self, title="选择文件",
                                               filetypes=[("xlsx", "*.xlsx"), ("xls", "*.xls"), ("txt", "*.txt")])
        data_repeated = [0, False]
        if file_path:
            data_update = pd.read_excel(file_path)
            # 将data_update中的数据更新到self.table中
            for i in range(len(data_update)):
                new_iid = str(uuid.uuid4())
                new_values = tuple(data_update.iloc[i])
                # 如果数据在表中已经存在，则不再插入
                if self.is_row_exists(new_values):
                    data_repeated[0] += 1
                    data_repeated[1] = True
                    continue
                else:
                    self.table.insert("", END, iid=new_iid, values=new_values, tags=("editable"))
            if data_repeated[1]:
                tm.showinfo("导入成功", "导入成功，其中有{}条数据重复".format(data_repeated[0]), parent=self)
            else:
                tm.showinfo("导入成功", "导入成功", parent=self)
            self.get_row()

        else:
            # 弹窗提示未选择文件
            tm.showerror("错误", "未选择文件", parent=self)

    def is_row_exists(self, target_row):
        identifiers = self.table.get_children()
        for identifier in identifiers:
            values = tuple(self.table.item(identifier)['values'])
            if values == target_row:
                return True
        return False
