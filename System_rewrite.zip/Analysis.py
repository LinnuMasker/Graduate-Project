import json
import os
import random
import sys
import pandas as pd
import matplotlib.pyplot as plt
from copy import deepcopy
from PSO_Python import *
from time import time, sleep


class Particles:
    def __init__(self, filelist):
        self.MAXX = 999999999999
        self.filelist = filelist
        self.p = []
        self.line = [Line(x) for x in range(5)]
        self.raw_time = []
        self.nc = []
        self.MMax = self.MMin = 0
        self.Tmax = -1
        self.Tmin = self.MAXX
        self.mutation_rate = 0.25
        self.initialize()

    def initialize(self):
        for i in self.filelist:
            self.p.append(Order(i))
        for i in self.p:
            i.self_init()
            i.randomize()
            self.line[i.currentL].ord.append(i.name - 1)
            self.line[i.currentL].currentN += 1
            self.line[i.currentL].totalT += i.getValue()

        self.raw_time = [self.line[i].totalT for i in range(1, 5)]
        self.fitness()

    def transplant(self, MMax, MMin, k):
        self.p[k].currentL = MMin
        self.line[MMax].totalT -= self.p[k].getValue(MMax)
        self.line[MMin].totalT += self.p[k].getValue(MMin)
        self.line[MMin].currentN += 1
        self.line[MMax].currentN -= 1
        self.line[MMin].ord.append(k)
        self.line[MMax].ord = [x for x in self.line[MMax].ord if x != k]

    def updates(self):
        self.nc = []
        self.nc = [i for i in range(len(self.p)) if self.p[i].mac[self.MMin] > 0 and self.p[i].currentL == self.MMax]
        if self.nc:
            rdm = random.randint(0, len(self.nc) - 1)
            self.transplant(self.MMax, self.MMin, self.nc[rdm])
        else:
            max_capacity = -1
            for i in self.line[self.MMax].ord:
                if self.p[i].capacity >= max_capacity:
                    max_capacity = self.p[i].capacity
            max_num = [i for i in self.line[self.MMax].ord if self.p[i].capacity == max_capacity]
            ncm = random.choice(max_num)
            num_line = [i for i in self.p[ncm].ll if i != self.MMax]
            mmk = random.choice(num_line)
            self.transplant(self.MMax, mmk, ncm)
        self.fitness()

    def mutates(self):
        for i in self.p:
            if random.random() < self.mutation_rate and i.capacity > 1:
                l = [x for x in i.ll if x != i.currentL]
                to_l = random.choice(l)
                self.transplant(i.currentL, to_l, i.name - 1)
        self.fitness()
        return self

    def fitness(self):
        self.Tmax, self.MMax = max((self.line[i].totalT, i) for i in range(1, 5))
        self.Tmin, self.MMin = min((self.line[i].totalT, i) for i in range(1, 5))


class HPSO:
    def __init__(self, data_in, par_number):
        self.data_in = data_in
        self.par_number = par_number
        self.ps = [Particles(self.data_in) for _ in range(self.par_number)]
        self.pBest = deepcopy(self.ps)
        self.gBest = min(self.pBest, key=lambda x: x.Tmax)
        self.times = 0

        while self.gBest.Tmax - self.gBest.Tmin > 10:
            self.times += 1
            self.ps = sorted(deepcopy(self.ps) + [i.mutates() for i in deepcopy(self.ps)], key=lambda x: x.Tmax)[
                      :self.par_number]
            for i in range(len(self.ps)):
                self.ps[i].updates()
                if self.ps[i].Tmax < self.pBest[i].Tmax:
                    self.pBest[i] = deepcopy(self.ps[i])
            self.gBest = min(self.pBest, key=lambda x: x.Tmax)
            if self.times > 200:
                break


if __name__ == '__main__':
    data = pd.read_excel("./database/testin.xlsx")
    data_in = []

    with open("./database/data.json") as f:
        jsons = json.load(f)
    for row in data.itertuples():
        item = (row.name, row.code, row.type, row.num)
        a = list(item)
        a += jsons[str(a[1])][a[2].strip()]
        data_in.append(a)
    t = []
    t.append(HPSO(data_in, 6).times)
    print(t)
