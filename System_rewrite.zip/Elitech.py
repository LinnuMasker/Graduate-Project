from mainwindow import MainWindow

if __name__ == '__main__':
    MainWindow().mainloop()
