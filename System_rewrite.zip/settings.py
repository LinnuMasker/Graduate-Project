import os
import sys
from tkinter import *
from database_setting import Database

import ttkbootstrap as ttks
from ttkbootstrap.constants import *


class Settings(Toplevel):
    def __init__(self, windows=None):
        super().__init__(windows)
        self.style = ttks.Style(theme='litera')
        self.title('设置')
        self.font_size = []
        self.par_num = [x for x in range(5, 51)]
        self.precision = [x * 0.5 for x in range(37)]
        for i in range(8, 49):
            self.font_size.append(i)
        self.attribute = {}
        with open("./configuration/setting.txt", "r", encoding='utf-8') as f:
            for i in f.readlines():
                s = i.split(':')
                self.attribute[s[0]] = s[1]
        self.crtsize = self.attribute['字体大小']
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        ww = 200
        wh = 300
        x = (sw - ww) / 2
        y = (sh - wh) / 2
        self.current_value = StringVar()
        self.current_par_num = StringVar()
        self.current_precision = StringVar()
        self.current_par_num.set(self.attribute['粒子个数'])
        self.current_value.set(self.attribute['字体大小'])
        self.current_precision.set(self.attribute['排程精度'])
        self.geometry("%dx%d+%d+%d" % (ww, wh, x, y))
        Label(self, text="字体大小").place(x=00, y=10, height=30)
        self.box1 = ttks.Combobox(self, value=self.font_size,
                                  textvariable=self.current_value, state="readonly", style=DARK)
        self.box1.place(x=60, y=10, height=30, width=130)
        # 建立text=粒子个数 的label与combobox
        Label(self, text="粒子个数").place(x=00, y=60, height=30)
        self.box2 = ttks.Combobox(self, value=self.par_num,
                                  textvariable=self.current_par_num, state="readonly", style=DARK)
        self.box2.place(x=60, y=60, height=30, width=130)
        # 建立text=排程精度 的label与combobox
        Label(self, text="排程精度").place(x=00, y=110, height=30)
        self.box3 = ttks.Combobox(self, value=self.precision,
                                  textvariable=self.current_precision, state="readonly", style=DARK)
        self.box3.place(x=60, y=110, height=30, width=130)

        self.datarw = ttks.Button(self, text="编辑数据库", command=self.process, bootstyle=SUCCESS)
        self.datarw.place(x=25, y=200, height=30, width=150)
        self.b1 = ttks.Button(self, text="确认", command=self.trans, bootstyle=SUCCESS)
        self.b1.place(x=10, y=260, width=60, height=30)
        self.b1 = ttks.Button(self, text="取消", command=self.destroy, bootstyle=(PRIMARY, "outline-toolbutton"))
        self.b1.place(x=130, y=260, width=60, height=30)

    def trans(self):
        self.crtsize = self.current_value.get()
        self.attribute['字体大小'] = self.crtsize
        self.attribute['粒子个数'] = self.current_par_num.get()
        self.attribute['排程精度'] = self.current_precision.get()
        with open("./configuration/setting.txt", "w", encoding='utf-8') as f:
            for i in self.attribute.items():
                f.write(':'.join(i).replace('\n', '') + '\n')
        self.destroy()

    def process(self):
        Database(self)
