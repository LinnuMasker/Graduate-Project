import sys
import os
import pandas as pd
import numpy as np
import xlsxwriter
import json

data = pd.read_excel("./database/database_raw.xlsx")

i = 0
database = {}
for row in data.itertuples():
    i += 1
    print(row)
    if row.Ordercode not in database:
        database[row.Ordercode] = {row.Ordertype.strip(): [0, 0, 0, 0, 0]}
        database[row.Ordercode][row.Ordertype.strip()][int(row.Line) - 1] = 1
        database[row.Ordercode][row.Ordertype.strip()][4] = row.stdT
    else:
        if row.Ordertype.strip() in database[row.Ordercode].keys():
            database[row.Ordercode][row.Ordertype.strip()][int(row.Line) - 1] = 1
            database[row.Ordercode][row.Ordertype.strip()][4] = row.stdT
        else:
            database[row.Ordercode].update(
                {row.Ordertype.strip(): [0, 0, 0, 0, 0]})
            database[row.Ordercode][row.Ordertype.strip()][int(row.Line) - 1] = 1
            database[row.Ordercode][row.Ordertype.strip()][4] = row.stdT

with open("./database/data_test.json", "w") as f:
    json.dump(database, f, indent=4)

'''excel = []
for code, i in database.items():
    for a, b in i.items():
        l1 = []
        l1.append(str(code))
        l1.append(a)
        l1 = l1 + b
        excel.append(l1)

df = pd.DataFrame(excel, columns=['Ordercode',
                                  'Ordertype', 'SMT1', 'SMT2', 'SMT3', 'SMT4', 'stdT'])
with pd.ExcelWriter('./database/confidential.xlsx', ) as writer:
    df.to_excel(writer, sheet_name='Sheet1', index=False)

    workbook = writer.book

    cell_format = workbook.add_format({'align': 'center'})
    worksheet = writer.sheets['Sheet1']
    worksheet.set_column('A:A', 30, cell_format)
    worksheet.set_column('B:B', 50, cell_format)
    worksheet.set_column('C:G', 10, cell_format)'''

'''
dfs = pd.read_excel("./database/testin.xls")
x = 1
a = []
s = []
for row in dfs.itertuples():
    print(row)
    a = []
    x += 1
    if x == 10:
        break
    a.append(row.name)
    a.append(row.code)
    a.append(row.type.strip())
    a.append(row.num)
    for j in content[str(row.code)][row.type.strip()]:
        a.append(j)
    s.append(a)

print(s)
'''
