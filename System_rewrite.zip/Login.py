import json
import tkinter.messagebox as tm
import ttkbootstrap as ttks

from tkinter import *
from ttkbootstrap.constants import *
from PIL import Image, ImageTk


class Login(Toplevel):
    def __init__(self, windows=None):
        super().__init__(windows)
        self.if_quit = False
        self.style = ttks.Style(theme='litera')
        self.title('SMT生产排程系统')
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        ww = 510
        wh = 130
        x = (sw - ww) / 2
        y = (sh - wh) / 2
        self.geometry("%dx%d+%d+%d" % (ww, wh, x, y))
        self.resizable(width=False, height=False)
        self.title("SMT生产排程系统")
        self.label1 = Label(self, text="用户名")
        self.label1.place(x=10 + 130, y=10, height=30)
        self.label2 = Label(self, text="密码")
        self.label2.place(x=10 + 130, y=50, height=30)
        self.entry1 = Entry(self)
        self.entry1.place(x=70 + 130, y=10, width=300, height=30)
        self.entry2 = Entry(self, show='*')
        self.entry2.place(x=70 + 130, y=50, width=300, height=30)
        self.b1 = Button(self, text="登录", command=self.login)
        self.b2 = Button(self, text="注册", command=self.register)
        self.b3 = Button(self, text="忘记密码", command=self.forget)
        self.b4 = Button(self, text="退出", command=self.qquit)
        # 重新放置四个按钮，使其在一行且对称均匀分布
        self.b1.place(x=10 + 130, y=90, width=80, height=30)
        self.b2.place(x=102.25 + 130, y=90, width=80, height=30)
        self.b3.place(x=197.25 + 130, y=90, width=80, height=30)
        self.b4.place(x=290 + 130, y=90, width=80, height=30)
        # 加载一个jpg图片文件，目录为"./picture/logo.jpg"
        self.image = Image.open('./picture/logo.png')
        self.photo = ImageTk.PhotoImage(self.image)
        self.label3 = Label(self, image=self.photo)
        self.label3.place(x=5, y=0, width=130, height=130)

        # 点击右上角的关闭按钮，结束程序
        self.protocol('WM_DELETE_WINDOW', self.qquit)

    def login(self):
        # 判断用户名与密码是否正确,参考user.json文件中的数据
        user = self.entry1.get()
        password = self.entry2.get()
        # 如果用户名或密码为空，则用户名密码都为admin
        if user == '' or password == '':
            user = 'admin'
            password = 'admin'
        with open('./configuration/user.json', 'r') as f:
            users = json.load(f)
        if user in users and password == users[user]:
            # 弹窗登录成功，销毁窗口
            tm.showinfo('提示', '登录成功')
            # 创建一个txt文件，用来存储当前登录的用户
            with open('./configuration/current_user.txt', 'w') as f:
                f.write(user)
            self.update()
            self.destroy()
        else:
            tm.showerror('错误', '用户名或密码错误')
            self.entry1.delete(0, END)
            self.entry2.delete(0, END)

    def register(self):
        # 创建一个toplevel，作为注册窗口
        self.register_window = Toplevel(self)
        # 窗口居中
        sw = self.register_window.winfo_screenwidth()
        sh = self.register_window.winfo_screenheight()
        ww = 300
        wh = 180
        x = (sw - ww) / 2
        y = (sh - wh) / 2
        self.register_window.geometry("%dx%d+%d+%d" % (ww, wh, x, y))
        self.register_window.title('注册')
        self.register_window.resizable(width=False, height=False)
        self.register_window.grab_set()
        self.register_window.focus_set()
        self.register_window.protocol('WM_DELETE_WINDOW', self.register_window.destroy)
        # 三个label与entry，分别用来显示与输入用户名，密码，确认密码
        self.register_label1 = Label(self.register_window, text='用户名')
        self.register_label1.place(x=10, y=10, height=30)
        self.register_label2 = Label(self.register_window, text='密码')
        self.register_label2.place(x=10, y=50, height=30)
        self.register_label3 = Label(self.register_window, text='确认密码')
        self.register_label3.place(x=10, y=90, height=30)
        self.register_entry1 = Entry(self.register_window)
        self.register_entry1.place(x=70, y=10, width=200, height=30)
        self.register_entry2 = Entry(self.register_window, show='*')
        self.register_entry2.place(x=70, y=50, width=200, height=30)
        self.register_entry3 = Entry(self.register_window, show='*')
        self.register_entry3.place(x=70, y=90, width=200, height=30)
        # 两个按钮，分别用来注册与取消
        self.register_button1 = Button(self.register_window, text='注册', command=self.register_user)
        self.register_button1.place(x=10, y=130, width=100, height=30)
        self.register_button2 = ttks.Button(self.register_window, text='取消', command=self.register_window.destroy,
                                            bootstyle=(PRIMARY, "outline-toolbutton"))
        self.register_button2.place(x=190, y=130, width=100, height=30)
        # 获取用户名与密码，以字典的形式写入user.json文件中

    def register_user(self):
        if self.register_entry2.get() == self.register_entry3.get():
            user = self.register_entry1.get()
            password = self.register_entry2.get()
            with open('./configuration/user.json', 'r') as f:
                users = json.load(f)
            if user in users:
                tm.showerror('错误', '用户名已存在')
                self.register_entry1.delete(0, END)
                self.register_entry2.delete(0, END)
                self.register_entry3.delete(0, END)
            else:
                users[user] = password
                with open('./configuration/user.json', 'w') as f:
                    json.dump(users, f, indent=4)
                tm.showinfo('提示', '注册成功')
                self.register_window.destroy()
        else:
            tm.showerror('错误', '密码不一致')
            self.register_entry2.delete(0, END)
            self.register_entry3.delete(0, END)

    def forget(self):
        # 创建一个toplevel，作为忘记密码窗口
        self.forget_window = Toplevel(self)
        # 窗口居中
        sw = self.forget_window.winfo_screenwidth()
        sh = self.forget_window.winfo_screenheight()
        ww = 300
        wh = 210
        x = (sw - ww) / 2
        y = (sh - wh) / 2
        self.forget_window.geometry("%dx%d+%d+%d" % (ww, wh, x, y))
        self.forget_window.title('忘记密码')
        self.forget_window.resizable(width=False, height=False)
        self.forget_window.grab_set()
        self.forget_window.focus_set()
        self.forget_window.protocol('WM_DELETE_WINDOW', self.forget_window.destroy)
        # 两个label与entry，分别用来显示与输入用户名，新密码，还需要两个entry与label，分别用来显示管理员的用户名与密码
        self.forget_label1 = Label(self.forget_window, text='用户名')
        self.forget_label1.place(x=10, y=10, height=30)
        self.forget_label2 = Label(self.forget_window, text='新密码')
        self.forget_label2.place(x=10, y=50, height=30)
        self.forget_label3 = Label(self.forget_window, text='管理员账号')
        self.forget_label3.place(x=10, y=90, height=30)
        self.forget_label4 = Label(self.forget_window, text='管理员密码')
        self.forget_label4.place(x=10, y=130, height=30)
        self.forget_entry1 = Entry(self.forget_window)
        self.forget_entry1.place(x=90, y=10, width=200, height=30)
        self.forget_entry2 = Entry(self.forget_window, show='*')
        self.forget_entry2.place(x=90, y=50, width=200, height=30)
        self.forget_entry3 = Entry(self.forget_window)
        self.forget_entry3.place(x=90, y=90, width=200, height=30)
        self.forget_entry4 = Entry(self.forget_window, show='*')
        self.forget_entry4.place(x=90, y=130, width=200, height=30)
        # 两个按钮，分别用来修改密码与取消，修改密码时需要管理员的账号与密码，如果管理员账号与密码正确，则修改密码，否则提示错误
        self.forget_button1 = ttks.Button(self.forget_window, text='修改密码', command=self.change_password)
        self.forget_button1.place(x=10, y=170, width=100, height=30)
        self.forget_button2 = ttks.Button(self.forget_window, text='取消', command=self.forget_window.destroy,
                                          bootstyle=(PRIMARY, "outline-toolbutton"))
        self.forget_button2.place(x=190, y=170, width=100, height=30)

    def qquit(self):
        self.if_quit = True
        self.destroy()
        quit()

    def change_password(self):
        user = self.forget_entry1.get()
        password = self.forget_entry2.get()
        admin = self.forget_entry3.get()
        admin_password = self.forget_entry4.get()
        with open('./configuration/user.json', 'r') as f:
            users = json.load(f)
        if admin in users and users[admin] == admin_password:
            users[user] = password
            with open('./configuration/user.json', 'w') as f:
                json.dump(users, f, indent=4)
            tm.showinfo('提示', '修改成功')
            self.forget_window.destroy()
        else:
            tm.showerror('错误', '管理员账号或密码错误')
            self.forget_entry3.delete(0, END)
            self.forget_entry4.delete(0, END)
