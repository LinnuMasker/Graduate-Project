import os
import sys
import json
import pystray
import uuid
import datetime
import threading
import tkinter.font as tf
import tkinter.messagebox as tm
import matplotlib.pyplot as plt
import pandas as pd
import ttkbootstrap as ttks

from PIL import Image as ims
from PIL import ImageTk
from time import time
from ttkbootstrap.constants import *
from subprocess import run
from tkinter import *
from tkinter import filedialog
from settings import Settings
from Login import Login
from PSO_Python import *
import pystray as pty
from openpyxl import load_workbook, Workbook, worksheet, cell, drawing, styles
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


class MainWindow(Tk):
    def __init__(self):
        super().__init__()
        with open('./configuration/current_user.txt', 'r') as f:
            self.current_user = f.read()
        # 初始化系统托盘
        self.tray_menu = (pty.MenuItem('当前用户:' + self.current_user, action=None, default=True),
                          pty.MenuItem('修改密码', self.change_password),
                          pty.Menu.SEPARATOR,
                          pty.MenuItem('返回主页面', self.show_window),
                          pty.MenuItem('隐藏主界面', self.withdraw),
                          pty.MenuItem('设置', self.change_setting),
                          pty.Menu.SEPARATOR,
                          pty.MenuItem('帮助', self.help),
                          pty.MenuItem('作者信息', self.author),
                          pty.MenuItem('退出', self.quit_window))
        self.tray_image = ims.open("./picture/tray.png")
        self.tray_icon = pty.Icon("icon", self.tray_image, "图标名称", self.tray_menu)
        # 初始化变量
        self.particle_num = 10
        self.attribute = {}
        self.select_path = StringVar()
        self.status = StringVar()
        self.status.set("你好，请选择订单文件")
        self.string = ''
        self.current_user = ''
        self.total_rows = 0
        self.if_xlsx = False
        self.data_input = []
        self.precision = 1
        self.gBest = 0
        self.picture_names = []
        # 初始化窗口
        self.title('SMT生产排程系统')
        self.style = ttks.Style(theme='litera')
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.menubar = Menu(self, tearoff=False)
        ww = 930
        wh = 700
        x = (sw - ww) / 2
        y = (sh - wh) / 2
        self.geometry("%dx%d+%d+%d" % (ww, wh, x, y))
        self.resizable(width=False, height=False)
        self.title("SMT生产排程系统")
        self.plot_var = BooleanVar()
        self.plot_var.set(True)
        self.plot_checkbox = Checkbutton(
            self, text="是否绘图", variable=self.plot_var, onvalue=True, offvalue=False)
        self.plot_checkbox.place(width=100, height=30, x=690 + 5, y=135)
        # All Image
        self.pyt = PhotoImage(file="./picture/data.png")
        self.pyt1 = PhotoImage(file="./picture/cumt.png")
        # All Label
        self.label1 = ttks.Label(self, text="文件路径")
        self.label1.place(x=10, y=110, height=30)
        self.label2 = Label(self, textvariable=self.status, justify=CENTER)
        self.label2.place(width=360, height=60, x=10, y=150)
        self.label3 = Label(self, image=self.pyt)
        self.label3.pack(anchor=CENTER)
        self.label4 = Label(self, image=self.pyt1)
        self.label4.place(x=375, y=110)
        # All Entry
        self.entry1 = Entry(self, textvariable=self.select_path)
        self.entry1.place(x=70, y=110, width=300, height=30)
        self.entry1.bind('<Button-3>', lambda x: self.rightKey(x, self.entry1))
        # All Button
        self.b1 = ttks.Button(self, text="选择文件", command=self.select_file, bootstyle=SUCCESS)
        self.b1.place(width=100, height=30, x=490, y=110)
        self.b2 = ttks.Button(self, text="读入数据", command=self.read, bootstyle=SUCCESS)
        self.b2.place(width=100, height=30, x=590 + 10, y=110)
        self.b3 = ttks.Button(self, text="开始排程", command=self.process, bootstyle=SUCCESS)
        self.b3.place(width=100, height=30, x=690 + 10 * 2, y=110)
        self.b4 = ttks.Button(self, text="导出", command=self.export, bootstyle=SUCCESS)
        self.b4.place(width=100, height=30, x=490, y=160)
        self.b5 = ttks.Button(self, text="清空", command=self.clc, bootstyle=SUCCESS)
        self.b5.place(width=100, height=30, x=590 + 10, y=160)
        self.b6 = ttks.Button(self, text="设置", command=self.change_setting, bootstyle=SUCCESS)
        self.b6.place(width=100, height=30, x=690 + 10 * 2, y=160)
        self.b7 = ttks.Button(self, text="数据视图", command=self.draw, bootstyle=SUCCESS)
        self.b7.place(width=100, height=30, x=790 + 10 * 3, y=110)
        self.b8 = ttks.Button(self, text="退出", command=sys.exit,
                              bootstyle=(PRIMARY, "outline-toolbutton"))
        self.b8.place(width=100, height=30, x=790 + 10 * 3, y=160)
        # All Menu
        self.Me = Menu(self.menubar, tearoff=False)
        self.usermenu = Menu(self.menubar, tearoff=False)
        with open('./configuration/current_user.txt', 'r') as f:
            self.current_user = f.read()
        self.usermenu.add_command(label="当前用户:" + self.current_user)
        self.usermenu.add_command(label="修改密码", command=self.change_password)
        self.usermenu.add_command(label="退出", command=self.destroy)
        self.helpmenu = Menu(self.menubar, tearoff=False)
        self.helpmenu.add_command(label="帮助", command=self.help)
        self.helpmenu.add_command(label="作者信息", command=self.author)
        # 将子菜单添加到菜单栏中
        self.Me.add_cascade(label="用户", menu=self.usermenu)
        self.Me.add_cascade(label="关于", menu=self.helpmenu)
        # 将菜单栏添加到窗口中
        self.config(menu=self.Me)

        # 多个界面
        self.notebook = ttks.Notebook(self)
        # 表格
        self.table = ttks.Treeview(self)
        self.table["columns"] = ('Ordernum', 'Ordercode', 'Ordertype', 'Num')
        self.table.column("#0", width=0)
        self.table.column("Ordernum", width=100, anchor='center')
        self.table.column("Ordercode", width=150, anchor='center')
        self.table.column("Ordertype", width=550, anchor='center')
        self.table.column("Num", width=100, anchor='center')
        self.table.heading("Ordernum", text="编号")
        self.table.heading("Ordercode", text="订单编号")
        self.table.heading("Ordertype", text="线路板类型")
        self.table.heading("Num", text="生产数量")
        self.table.bind('<Button-3>', lambda x: self.rightKey(x, self.table))
        # 滚轮
        self.scroll1 = Scrollbar(self, command=self.table.yview)
        self.table.configure(yscrollcommand=self.scroll1.set)
        self.scroll1.place(width=20, height=420, x=910, y=250 + 20)

        self.notebook.place(width=900, height=450, x=10, y=250 - 10)
        self.notebook.add(self.table, text="待加工订单")

        self.protocol("WM_DELETE_WINDOW", self.ask_quit)
        threading.Thread(target=self.tray_icon.run, daemon=True).start()

        # self.bind("<FocusIn>", self.update_settings)
        self.user_login()

    def cut(self, editor, event=None):
        editor.event_generate("<<Cut>>")

    def copy(self, editor, event=None):
        editor.event_generate("<<Copy>>")

    def paste(self, editor, event=None):
        editor.event_generate('<<Paste>>')

    def rightKey(self, event, editor):
        self.menubar.delete(0, 'end')
        self.menubar.add_command(label='复制', command=lambda: self.copy(editor))
        self.menubar.add_command(label='粘贴', command=lambda: self.paste(editor))
        self.menubar.add_command(label='剪切', command=lambda: self.cut(editor))
        self.menubar.post(event.x_root, event.y_root)

    def select_file(self):
        selected_file_path = filedialog.askopenfilename(title='选择文件',
                                                        filetypes=[('xlsx', '*.xlsx'),
                                                                   ('txt', '*.txt'),
                                                                   ('xls', '*.xls')])
        self.select_path.set(selected_file_path)

    def read(self):
        self.data_input.clear()
        with open('./database/data.json', 'r') as f:
            jsons = json.load(f)
        self.clc()
        filename = ''
        filename = str(self.select_path.get())
        if (filename == ''):
            tm.showwarning(title="警告", message="请选择文件")
            return
        req = filename.split('.')
        if (req[1] == 'txt'):
            self.if_xlsx = False
            with open(filename, 'r', encoding='utf-8') as f:
                self.string = ""
                content = f.readlines()
                for i, item in enumerate(content):
                    a = []
                    new_iid = str(uuid.uuid4())
                    self.table.insert(parent='', index=i, iid=new_iid, values=item.split("\t"))
                    # 去除行尾的换行符
                    item = item.strip()
                    a += item.split("\t")
                    a += jsons[a[1]][a[2].strip()]
                    self.data_input.append(a)
        elif (req[1] == 'xlsx' or req[1] == 'xls'):
            self.if_xlsx = True
            self.data = pd.read_excel(filename)
            for row in self.data.itertuples():
                a = []
                new_iid = str(uuid.uuid4())
                item = (row.name, row.code, row.type, row.num)
                self.table.insert(parent='', index=row.Index, iid=new_iid, values=item)
                a = list(item)
                a += jsons[str(a[1])][a[2].strip()]
                self.data_input.append(a)
        self.get_row()
        self.status.set("订单数据读入完成，共" + str(self.total_rows) + "个订单")

    def export(self):
        filename = ''
        selected_file_path = filedialog.asksaveasfilename(title='选择文件',
                                                          filetypes=[('xlsx', '*.xlsx'), ('txt', '*.txt'),
                                                                     ('xls', '*.xls')], defaultextension='.xlsx')
        filename = selected_file_path
        if (filename == ''):
            tm.showwarning(title="警告", message="请选择导出文件")
            return
        reqs = selected_file_path.split('.')
        if (reqs[1] == 'txt'):
            with open(selected_file_path, "w", encoding='utf-8') as f:
                # 按行写入data_out中的数据
                for i in self.data_out:
                    for j in i:
                        for k in j:
                            f.write(str(k) + " ")
                        f.write("\n")

            # 保存成功提示,询问是否打开文件
            if (tm.askyesno(title="提示", message="导出成功，是否打开文件？")):
                os.startfile(selected_file_path)
        elif (reqs[1] == 'xlsx' or reqs[1] == 'xls'):
            # 将self.data_out中的数据写入excel表格
            with pd.ExcelWriter(selected_file_path) as writer:
                for i in range(len(self.data_out)):
                    df = pd.DataFrame(self.data_out[i], columns=['订单编号', '线路板类型', '生产用时', '生产天数'])
                    df.to_excel(writer, sheet_name='SMT' + str(i + 1), index=False)
                    # 所有数据居中
                    workbook = writer.book
                    worksheet = writer.sheets['SMT' + str(i + 1)]
                    cell_format = workbook.add_format({'align': 'center'})
                    worksheet.set_column('A:A', 30, cell_format)
                    worksheet.set_column('B:B', 50, cell_format)
                    worksheet.set_column('C:C', 20, cell_format)
                    worksheet.set_column('D:D', 20, cell_format)
            self.set_center(selected_file_path)
            # 保存成功提示,询问是否打开文件
            if (tm.askyesno(title="提示", message="导出成功，是否打开文件？")):
                os.startfile(selected_file_path)

    def clc(self):
        for child in self.table.get_children():
            self.table.delete(child)
        # 如果notebook有多个表格，只保留notebook中的第一个表格
        if (len(self.notebook.tabs()) > 1):
            for i in range(len(self.notebook.tabs()) - 1):
                self.notebook.forget(1)

    def change_setting(self):
        Settings(self).wait_window()
        self.update_settings()

    def draw(self):
        if self.gBest == 0:
            tm.showwarning(title="警告", message="请先进行排程")
            return

        draw_windows = Toplevel(self)
        draw_windows.geometry("1600x900")
        draw_windows.title("数据视图")
        draw_notebook = ttks.Notebook(draw_windows)
        draw_notebook.pack(fill='both', expand=True)

        for i in self.picture_names:
            # 读取图片
            img = ims.open(i)
            # 创建一个label用于显示图片
            label = Label(draw_notebook)
            label.pack()
            # 将图片放在label上
            label.img = ImageTk.PhotoImage(img)
            label.config(image=label.img)
            draw_notebook.add(label, text=i.split("/")[-1])

    def process(self):
        self.picture_names.clear()
        plt.switch_backend('agg')
        if not self.data_input:
            tm.showwarning(title="警告", message="请先导入订单数据")
            return
        self.time1 = time()
        if (len(self.notebook.tabs()) > 1):
            for i in range(len(self.notebook.tabs()) - 1):
                self.notebook.forget(1)
        self.particle = [Particles(self.data_input, self.precision) for _ in range(int(self.particle_num))]
        self.gBest = min(self.particle, key=lambda x: x.GTmax)
        self.data_out = [[] for i in range(4)]
        tables = []
        for i in range(1, 5):
            t = ttks.Treeview(self)
            t["columns"] = ('Ordercode', 'Ordertype', 'stdT', 'days')
            t.column("#0", width=0)
            t.column("Ordercode", width=150)
            t.column("Ordertype", width=450)
            t.column("stdT", width=150, anchor='center')
            t.column("days", width=150, anchor='center')
            t.heading("Ordercode", text="订单编号")
            t.heading("Ordertype", text="线路板类型")
            t.heading("stdT", text="生产用时")
            t.heading("days", text="加工日期")
            tables.append(t)
            self.notebook.add(t, text="SMT" + str(i))
        for i in range(1, 5):
            self.gBest.operate(i)
            self.data_out[i - 1] = self.gBest.real_data
            for j in self.gBest.real_data:
                tables[i - 1].insert('', 'end', values=j)
        self.time2 = time()
        if self.plot_var.get() == True:
            self.save_pictures()
        # 弹窗提示排程完成，不要声音
        tm.showinfo(title="提示", message="排程完成,共迭代{}次".format(self.gBest.time_count))
        # 创建一个label，当选中不同的表格时，label的内容会改变
        self.label = Label(self, text="", justify=CENTER)
        self.label.place(width=360, height=30, x=10, y=200)
        self.notebook.bind("<<NotebookTabChanged>>", self.tab_changed)
        # notebook 跳转到第二个表格
        self.notebook.select(1)
        self.status.set("排程完成，共" + str(self.total_rows) + "个订单")

    def tab_changed(self, event):
        # 将scroll1的滚动条绑定到当前表格
        self.notebook.nametowidget(self.notebook.select()).configure(yscrollcommand=self.scroll1.set)
        self.scroll1.config(command=self.notebook.nametowidget(self.notebook.select()).yview)
        # 点击第一个表格，intext设置为空字符串
        if (self.notebook.index(self.notebook.select()) == 0):
            self.label['text'] = ""
            return
        conr = {"SMT1": 1, "SMT2": 2, "SMT3": 3, "SMT4": 4}
        intext = self.notebook.tab(self.notebook.select(), "text") + "线总共用时：" + str(
            round(self.gBest.TimeBest[conr[self.notebook.tab(self.notebook.select(), "text")]], 3)) + "小时"
        self.label['text'] = intext

    def update_settings(self, event=None):
        with open("./configuration/setting.txt", "r", encoding='utf-8') as f:
            for i in f.readlines():
                s = i.split(':')
                self.attribute[s[0]] = s[1]
        self.style.configure("Treeview", font=("TkDefaultFont", int(self.attribute['字体大小'])))
        self.particle_num = self.attribute['粒子个数']
        self.precision = self.attribute['排程精度']

    def change_password(self):
        # 创建一个新窗口，用于修改密码
        self.newWindow = Toplevel(self)
        self.newWindow.title("修改密码")
        self.newWindow.resizable(0, 0)
        self.newWindow.grab_set()
        self.newWindow.focus_set()
        self.newWindow.transient(self)
        self.newWindow.protocol("WM_DELETE_WINDOW", self.newWindow.destroy)
        # 窗口居中
        width = 300
        height = 200
        x = (self.newWindow.winfo_screenwidth() - width) / 2
        y = (self.newWindow.winfo_screenheight() - height) / 2
        self.newWindow.geometry("%dx%d+%d+%d" % (width, height, x, y))

        # 创建一个标签，用于显示提示信息
        self.label11 = Label(self.newWindow, text="请输入原密码：")
        self.label11.place(x=10, y=20)
        # 创建一个输入框，用于输入原密码
        self.entry11 = Entry(self.newWindow, show="*")
        self.entry11.place(x=120, y=20)
        # 创建一个标签，用于显示提示信息
        self.label21 = Label(self.newWindow, text="请输入新密码：")
        self.label21.place(x=10, y=60)
        # 创建一个输入框，用于输入新密码
        self.entry21 = Entry(self.newWindow, show="*")
        self.entry21.place(x=120, y=60)
        # 创建一个标签，用于显示提示信息
        self.label31 = Label(self.newWindow, text="请再次输入新密码：")
        self.label31.place(x=10, y=100)
        # 创建一个输入框，用于再次输入新密码
        self.entry31 = Entry(self.newWindow, show="*")
        self.entry31.place(x=120, y=100)
        # 创建一个按钮，用于提交修改
        self.button11 = ttks.Button(self.newWindow, text="提交", command=self.submit, bootstyle=SUCCESS)
        # 创建一个按钮，用于取消修改
        self.button21 = ttks.Button(self.newWindow, text="取消", command=self.newWindow.destroy,
                                    bootstyle=(PRIMARY, "outline-toolbutton"))
        # 两个按钮在一行，均匀分布，宽度为100，高度为30，间隔为20
        self.button11.place(x=20, y=150, width=100, height=30)
        self.button21.place(x=180, y=150, width=100, height=30)
        # 绑定回车键，提交修改
        self.newWindow.bind("<Return>", self.submit)

    def submit(self, event=None):
        # 将新密码写入json
        with open("./configuration/user.json", "r", encoding='utf-8') as f:
            self.user = json.load(f)
        if self.entry11.get() == self.user[self.current_user]:
            if self.entry21.get() == self.entry31.get():
                self.user[self.current_user] = self.entry21.get()
                with open("./configuration/user.json", "w", encoding='utf-8') as f:
                    json.dump(self.user, f, indent=4)
                tm.showinfo(title="提示", message="密码修改成功")
                self.newWindow.destroy()
            else:
                tm.showwarning(title="警告", message="两次输入的密码不一致")
        else:
            tm.showwarning(title="警告", message="请输入正确的密码")

    def get_row(self):
        last_item_id = self.table.get_children()[-1]
        self.total_rows = int(self.table.index(last_item_id)) + 1
        return self.total_rows

    def user_login(self):
        self.state('iconic')
        l = Login(self)
        l.wait_window()
        # 从任务栏弹出主页面
        if l.if_quit == False:
            self.state('normal')
            self.update_settings()
        else:
            self.destroy()

    def set_center(self, filename):
        workbook = load_workbook(filename)
        wst = ["SMT1", "SMT2", "SMT3", "SMT4"]
        for i in wst:
            worksheet = workbook[i]
            start_row, end_row = 1, 1
            prev_value = worksheet.cell(row=start_row, column=4).value
            for row in range(2, worksheet.max_row + 1):
                current_value = worksheet.cell(row=row, column=4).value
                if current_value != prev_value:
                    if end_row - start_row > 0:
                        worksheet.merge_cells(start_row=start_row, start_column=4, end_row=end_row, end_column=4)
                    start_row = row
                end_row = row
                prev_value = current_value
            if end_row - start_row > 0:
                worksheet.merge_cells(start_row=start_row, start_column=4, end_row=end_row, end_column=4)

            s = 'D1:D' + str(worksheet.max_row)
            cells = worksheet[s]
            for row in cells:
                for cell in row:
                    cell.alignment = styles.Alignment(vertical='center', horizontal='center')
        workbook.save(filename)

    def help(self):
        # 打开readme.txt文件夹，存储位置与主程序同一目录
        os.startfile("readme.txt")

    def author(self):
        # 打开作者信息文件夹，存储位置与主程序同一目录
        os.startfile("author.txt")

    def ask_quit(self, event=None):
        # 弹窗询问是否退出，若是则quit()，否则self.withdraw()
        if tm.askokcancel("退出", "确定要退出吗？"):
            sys.exit()
        else:
            if tm.askokcancel("最小化", "确定要最小化到任务栏吗？"):
                self.withdraw()
            else:
                return

    def show_window(self):
        self.deiconify()
        self.focus_set()

    def quit_window(self, icon: pystray.Icon):
        self.tray_icon.stop()
        sys.exit()

    def save_pictures(self):
        self.picture_names.clear()
        plt.switch_backend('agg')
        plt.figure(figsize=(16, 9), dpi=100)
        for i in self.particle:
            x = [i[0] for i in i.iter]
            y = [i[1] for i in i.iter]
            plt.step(x, y, where="post")
            # 设置图像的大小
        now = datetime.datetime.now()
        plt.title('Iteration Time Use(sec):' + str(round(self.time2 - self.time1, 3)))
        plt.xlabel('X')
        plt.ylabel('Y')
        # 保存绘制的图形
        picture_name = "./picture/draw/iteration/" + now.strftime("%Y-%m-%d-%H_%M_%S") + "_Iteration.png"
        self.picture_names.append(picture_name)
        plt.savefig(picture_name, bbox_inches='tight')

        plt.figure(figsize=(16, 9), dpi=100)
        x = [i.time_count for i in self.particle]
        y = [i.GTmax for i in self.particle]
        plt.scatter(x, y)
        plt.title('Iteration Scatter Graphy')
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.ylim(260, 280)
        picture_name = "./picture/draw/scatter/" + now.strftime("%Y-%m-%d-%H_%M_%S") + "_scatter.png"
        self.picture_names.append(picture_name)
        plt.savefig(picture_name, bbox_inches='tight')

        plt.figure(figsize=(16, 9), dpi=100)
        plt.rcParams["font.sans-serif"] = ["SimHei"]
        plt.rcParams["axes.unicode_minus"] = False
        data = [self.gBest.TimeBest[i] for i in range(1, 5)]
        pre = self.gBest.raw_time
        plt.title("优化前后SMT产线生产总时间对比", fontsize=17)
        plt.xlabel("加工时间/小时", fontsize=15)
        plt.ylabel("SMT产线", fontsize=15)
        das = []
        time = []
        for i in data:
            time.append(round(i, 3))

        for i in pre:
            time.append(round(i, 3))

        plt.yticks([1, 2, 3, 4, 5, 6, 7, 8], ["SMT1", "SMT2",
                                              "SMT3", "SMT4", "SMT1", "SMT2", "SMT3", "SMT4"])
        plt.barh(range(5, 9), time[4:], left=0,
                 height=0.5, label="改善前生产时间", color="gray")
        plt.barh(range(1, 5), time[:4], left=0, height=0.5, label="生产时间")
        # 将数据标注在柱状图上,且位置位于每个柱状图的顶端的正下方
        for x, y in enumerate(time[:4]):
            plt.text(y + 0.1, x + 1, '%s' % y, va='center')
        for x, y in enumerate(time[4:]):
            plt.text(y + 0.1, x + 5, '%s' % y, va='center')

        plt.legend(loc=4)
        now = datetime.datetime.now()
        files_name = "./picture/draw/comparison/" + now.strftime("%Y-%m-%d-%H_%M_%S") + "_result.png"
        self.picture_names.append(files_name)
        plt.savefig(files_name)
