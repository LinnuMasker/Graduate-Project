import json
import os
import random
import sys
import pandas as pd
from copy import deepcopy
from time import time
import numpy as np


class Order:

    def __init__(self, namelist):
        self.ll = []
        self.mac = [-1, 0, 0, 0, 0]
        self.name = int(namelist[0])
        self.code = namelist[1]
        self.type = namelist[2]
        self.number = float(namelist[3])
        self.mac[1] = int(namelist[4])
        self.mac[2] = int(namelist[5])
        self.mac[3] = int(namelist[6])
        self.mac[4] = int(namelist[7])
        self.stdT = float(namelist[8])
        self.Tc = 0.05 * self.number * self.stdT / 60
        self.Ts = 0.05 * self.number * self.stdT / 60
        self.timeT = self.stdT * self.number / 3600 + \
                     0.3 * self.Tc / 60 + 0.3 * self.Ts / 60
        self.timeT = round(self.timeT, 3)
        self.pBest = 0
        self.currentL = 0
        self.capacity = 0

    def getValue(self, x=None):
        if x is None:
            x = self.currentL
        return round(self.timeT / self.mac[x], 3)

    def getLineNumber(self):
        return self.capacity

    def self_init(self):
        self.ll.clear()

    def randomize(self):
        for i in range(1, 5):
            if self.mac[i] > 0.00:
                self.ll.append(i)
        self.rad = random.randrange(len(self.ll))
        self.currentL = self.pBest = self.ll[self.rad]
        self.capacity = len(self.ll)

    def OutSting(self):
        return [self.name, self.currentL, self.mac[self.currentL]]


class Line:

    def __init__(self, num):
        self.totalT = 0
        self.prior = 0
        self.totalN = 0
        self.currentN = 0
        self.ord = []
        self.series = num

    def init(self):
        self.totalT = 0
        self.prior = 0
        self.totalN = 0
        self.currentN = 0
        self.ord = []


class Particle:
    def __init__(self, particles, recordings, codes=None):
        self.encode_reference = {1: "1000",
                                 2: "0100",
                                 3: "0010",
                                 4: "0001"}

        self.decode_reference = {"1000": 1,
                                 "0100": 2,
                                 "0010": 3,
                                 "0001": 4}
        self.particle_code = []
        self.mutation_rate = 0.2
        self.p = np.array(particles)
        self.line = np.array([Line(x) for x in range(5)])
        self.Tmax = 0
        self.Tmin = 0
        self.max_index = 0
        self.min_index = 0
        self.recording = np.array(recordings)

        if codes is None:
            for i in self.p:
                i.randomize()
                self.line[i.currentL].totalT += round(i.getValue(), 2)
                self.fitness()
            self.encode()
        else:
            self.particle_code = np.array(codes)
            self.decode()

        # self.update()

    def encode(self):
        for i in self.p:
            self.particle_code.append(self.encode_reference[i.currentL])

    def decode(self):
        for i in self.line:
            i.init()
        for index, item in enumerate(self.particle_code):
            i = self.decode_reference[item]
            self.line[i].totalT += self.p[index].getValue(i)

        self.fitness()

    def mutation(self):
        for i in range(len(self.particle_code)):
            if random.random() < self.mutation_rate:
                x = self.encode_reference[random.choice([i for i in self.p[i].ll])]
                self.particle_code[i] = x
        self.decode()

    def crossover(self, p2):
        crossover_point = random.randint(0, len(self.particle_code))
        p1 = deepcopy(self.particle_code)
        p2 = deepcopy(p2.particle_code)
        p3 = p1[:crossover_point] + p2[crossover_point:]
        p4 = p2[:crossover_point] + p1[crossover_point:]
        return (p3, p4)

    def update(self):
        self.O_max_min = []

        for i, j, k in zip(self.particle_code, self.recording, range(len(self.particle_code))):
            if self.decode_reference[i] == self.max_index:
                if int(self.encode_reference[self.min_index], 2) & int(j, 2) == \
                        int(self.encode_reference[self.min_index], 2):
                    self.O_max_min.append(k)

        if self.O_max_min:
            rand = random.randint(0, len(self.O_max_min) - 1)
            self.particle_code[self.O_max_min[rand]] = self.encode_reference[self.min_index]
        else:
            '''
            l_max = []
            for i in range(len(self.particle_code)):
                if self.particle_code[i] == self.encode_reference[self.max_index]:
                    l_max.append(i)
            '''
            l_max = [i for i, code in enumerate(self.particle_code) if code == self.encode_reference[self.max_index]]
            l_max_r = [self.recording[i] for i in l_max]
            max_num = max(range(len(l_max_r)), key=lambda i: l_max_r[i].count('1'))
            dis = int(l_max_r[max_num], 2) - int(self.encode_reference[self.max_index], 2)
            code = str(bin(dis)[2:].zfill(4))
            indices = [i for i in range(len(code)) if code[i] == '1']
            random_index = random.choice(indices)
            self.particle_code[l_max[max_num]] = self.encode_reference[random_index + 1]
        self.decode()

    def fitness(self):
        self.Tmax = max(k.totalT for k in self.line)
        self.max_index = max(enumerate(self.line), key=lambda x: x[1].totalT)[0]
        self.Tmin = min(self.line[k].totalT for k in range(1, 5))
        sorted_list = sorted(self.line, key=lambda x: x.totalT)
        second_smallest = sorted_list[1]
        self.min_index = second_smallest.series


class Modified_PSO:
    def __init__(self, data_in, recording):
        self.data_in = data_in
        self.p = []
        x = recording
        for i in self.data_in:
            self.p.append(Order(i))

        self.particle_swarm = [Particle(particles=self.p, recordings=x) for _ in range(10)]
        self.particle_mutation = [Particle(particles=self.p, recordings=x) for _ in range(10)]
        self.particle_crossover = deepcopy(self.particle_swarm)
        self.pBest = deepcopy(self.particle_swarm)
        self.gBest = min(self.pBest, key=lambda x: x.Tmax)

        times = 0
        ins1 = time()
        while True:
            times += 1
            for i in self.particle_mutation:
                i.mutation()
            sss = deepcopy(self.particle_swarm) + deepcopy(self.particle_mutation)
            ssss = sorted(sss, key=lambda x: x.Tmax)[:10]
            self.particle_swarm = deepcopy(ssss)
            for i in range(len(self.particle_swarm)):
                self.particle_swarm[i].update()
                if self.particle_swarm[i].Tmax < self.pBest[i].Tmax:
                    self.pBest[i] = deepcopy(self.particle_swarm[i])
            self.gBest = min(self.pBest, key=lambda x: x.Tmax)
            if self.gBest.Tmax - self.gBest.Tmin <= 10 or times >= 200:
                break
        ins2 = time()
        print([self.gBest.line[i].totalT for i in range(1, 5)], "\n", ins2 - ins1, times)


data = pd.read_excel("./database/testin.xlsx")
data_in = []

with open("./database/data.json") as f:
    jsons = json.load(f)
recording = []
for row in data.itertuples():
    item = (row.name, row.code, row.type, row.num)
    a = list(item)
    a += jsons[str(a[1])][a[2].strip()]
    recording.append("".join([str(i) for i in jsons[str(a[1])][a[2].strip()][:4]]))
    data_in.append(a)
Modified_PSO(data_in, recording)
