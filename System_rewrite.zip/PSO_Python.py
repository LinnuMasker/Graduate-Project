import json
import os
import random
import sys
import pandas as pd
from copy import deepcopy


class Order:

    def __init__(self, namelist):
        self.ll = []
        self.mac = [-1, 0, 0, 0, 0]
        self.name = int(namelist[0])
        self.code = namelist[1]
        self.type = namelist[2]
        self.number = float(namelist[3])
        self.mac[1] = int(namelist[4])
        self.mac[2] = int(namelist[5])
        self.mac[3] = int(namelist[6])
        self.mac[4] = int(namelist[7])
        self.stdT = float(namelist[8])
        self.Tc = 0.05 * self.number * self.stdT / 60
        self.Ts = 0.05 * self.number * self.stdT / 60
        self.timeT = self.stdT * self.number / 3600 + \
                     0.3 * self.Tc / 60 + 0.3 * self.Ts / 60
        self.timeT = round(self.timeT, 3)
        self.pBest = 0
        self.currentL = 0
        self.capacity = 0

    def getValue(self, x=None):
        if x is None:
            x = self.currentL
        return round(self.timeT / self.mac[x], 3)

    def getLineNumber(self):
        return self.capacity

    def self_init(self):
        self.ll.clear()

    def randomize(self):
        for i in range(1, 5):
            if self.mac[i] > 0.00:
                self.ll.append(i)
        self.rad = random.randrange(len(self.ll))
        self.currentL = self.pBest = self.ll[self.rad]
        self.capacity = len(self.ll)

    def OutSting(self):
        return [self.name, self.currentL, self.mac[self.currentL]]


class Line:

    def __init__(self, num):
        self.totalT = 0
        self.prior = 0
        self.totalN = 0
        self.currentN = 0
        self.ord = []
        self.series = num

    def init(self):
        self.totalT = 0
        self.prior = 0
        self.totalN = 0
        self.currentN = 0
        self.ord = []


class Updater:

    def __init__(self, filelist, precision):
        self.iter = []
        self.precision = precision
        self.time_count = 0
        self.filelist = filelist
        self.ENDTIME = 500
        self.MAXX = 999999999999
        self.Iteration = 500
        self.p = []
        self.mark = False
        self.times = 0
        self.rdm = -1
        self.interval = 0
        self.pre_interval = 0
        self.cancel = 0
        self.MMax = self.MMin = 0
        self.GTmax = self.MAXX
        self.GTmin = -1
        self.nc = []
        self.record = self.MAXX
        self.TimeBest = [-1, 0, 0, 0, 0]
        self.line = [Line(x) for x in range(5)]
        self.HousLimit = -1
        self.ans_len = []
        self.ans_T = []
        self.lBest = []
        self.Pgbest = []
        self.raw_time = []
        self.mutation_rate = 0.2

    def read_files(self):
        for i in self.filelist:
            self.p.append(Order(i))

        for i in self.p:
            i.self_init()
            i.randomize()
            self.line[i.currentL].ord.append(i.name - 1)
            self.line[i.currentL].currentN += 1
            self.line[i.currentL].totalT += i.getValue()
            self.HousLimit = max(self.HousLimit, int(i.timeT / 0.88) + 1)

        self.raw_time = [self.line[i].totalT for i in range(1, 5)]

        if self.HousLimit <= 8:
            self.HousLimit = 8
        elif self.HousLimit > 8 and self.HousLimit <= 18:
            self.HousLimit = 18
        elif self.HousLimit >= 18:
            self.HousLimit = 20

    def SaveTheBestSolution(self):
        self.lBest.clear()
        for i in self.p:
            i.pBest = i.currentL
        self.Pgbest = self.p
        for i in range(1, 5):
            self.lBest.append(self.line[i].ord)
            self.TimeBest[i] = self.line[i].totalT

    def transplant(self, MMax, MMin, k):
        self.p[k].currentL = MMin
        self.line[MMax].totalT -= self.p[k].getValue(MMax)
        self.line[MMin].totalT += self.p[k].getValue(MMin)
        self.line[MMin].currentN += 1
        self.line[MMax].currentN -= 1
        self.line[MMin].ord.append(k)
        self.line[MMax].ord = [x for x in self.line[MMax].ord if x != k]

    def PSO_Process(self):
        while True:
            self.time_count += 1

            if not self.mark:
                self.interval += 1
            else:
                break

            self.Tmax = -1
            self.Tmin = self.MAXX
            self.nc = []

            self.Tmax, self.MMax = max((self.line[i].totalT, i) for i in range(1, 5))
            self.Tmin, self.MMin = min((self.line[i].totalT, i) for i in range(1, 5))

            if self.Tmax <= self.GTmax:
                self.GTmax = self.Tmax
                self.GTmin = self.Tmin
                self.interval = 0
                self.Pre_interval = 0
                self.SaveTheBestSolution()

            self.iter.append((self.time_count, self.GTmax))

            if self.GTmax - self.GTmin < float(self.precision):
                self.mark = True

            if self.Pre_interval == 0 and self.interval == 1:
                self.cancel += 1

            if self.interval >= self.ENDTIME or self.cancel >= self.ENDTIME:
                self.mark = True

            for i in range(len(self.p)):
                if self.p[i].mac[self.MMin] > 0 and self.p[i].currentL == self.MMax:
                    self.nc.append(i)

            if self.nc:
                self.rdm = random.randint(0, len(self.nc) - 1)
                self.transplant(self.MMax, self.MMin, self.nc[self.rdm])
            else:
                '''self.ncm, mmk = max(self.line[self.MMax].ord,
                                    key=lambda x: self.p[x].getLineNumber()), 0
                for num in self.p[self.ncm].ll:
                    if num != self.MMax:
                        if self.p[self.ncm].mac[num] >= self.p[self.ncm].mac[mmk]:
                            mmk = num'''
                max_capacity = -1
                for i in self.line[self.MMax].ord:
                    if self.p[i].capacity >= max_capacity:
                        max_capacity = self.p[i].capacity
                max_num = [i for i in self.line[self.MMax].ord if self.p[i].capacity == max_capacity]
                self.ncm = random.choice(max_num)
                num_line = [i for i in self.p[self.ncm].ll if i != self.MMax]
                mmk = random.choice(num_line)
                self.transplant(self.MMax, mmk, self.ncm)

    def PSO(self):
        self.read_files()
        self.PSO_Process()

    def mutatation(self):
        for i in self.p:
            if random.random() < self.mutation_rate and i.capacity > 1:
                l = [x for x in i.ll if x != i.currentL]
                to_l = random.choice(l)
                self.transplant(i.currentL, to_l, i.name - 1)


class Particles(Updater):

    def __init__(self, filelist, precision):
        super().__init__(filelist, precision)
        self.PSO()
        self.ans_len = [len(x) for x in self.lBest]
        self.P_ans = []
        self.pl = []

    def operate(self, index):
        self.pl = self.lBest[index - 1]
        self.pl = sorted(self.pl, key=lambda x: self.Pgbest[
            x].getValue(index), reverse=True)
        record = []
        self.ans1 = []
        days, k, mins = 0, -1, 9999999
        hours = [0 for i in range(50)]

        while len(self.pl) != 0:
            mins = 9999999
            k = -1
            for i in range(len(self.pl)):
                if hours[days] + self.Pgbest[self.pl[i]].getValue(index) <= self.HousLimit:
                    if self.HousLimit - hours[days] - self.Pgbest[self.pl[i]].getValue(index) <= mins:
                        mins = self.HousLimit - \
                               hours[days] - \
                               self.Pgbest[self.pl[i]].getValue(index)
                        k = i
            if k == -1:
                days += 1
                self.ans1.append(record)
                record = []
            else:
                record.append(self.pl[k])
                hours[days] += self.Pgbest[self.pl[k]].getValue(index)
                del self.pl[k]

        self.ans1.append(record)
        record = []
        days += 1
        self.real_data = []
        while len(hours) > 0 and hours[-1] == 0:
            hours.pop()
        for i in range(len(hours)):
            for j in self.ans1[i]:
                l = [self.Pgbest[j].code, self.Pgbest[j].type, round(self.Pgbest[j].getValue(index), 2),
                     "第" + str(i + 1) + "天"]
                self.real_data.append(l)

    def crossover(self, p1, p2):
        cross_point = random.randint(len(p1.p))
        p3 = p1[:cross_point] + p2[cross_point:]
        p4 = p2[:cross_point] + p1[cross_point:]
        p1.p = p3
        p2.p = p4
        return p1, p2
